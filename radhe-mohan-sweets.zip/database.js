const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

// Data directory and file paths
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const ITEMS_FILE = path.join(DATA_DIR, 'items.json');
const FEEDBACK_FILE = path.join(DATA_DIR, 'feedback.json');

// --- Helper functions ---

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJSON(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return [];
    }
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err.message);
    return [];
  }
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// --- Seed data ---

function seedDatabase() {
  // Seed admin user
  if (!fs.existsSync(USERS_FILE) || readJSON(USERS_FILE).length === 0) {
    const adminPassword = bcrypt.hashSync('admin123', 10);
    const adminUser = {
      id: uuidv4(),
      name: 'Rakesh Gupta',
      phone: '9996008512',
      email: 'admin@radhemohansweets.com',
      address: '',
      password: adminPassword,
      isAdmin: true,
      createdAt: new Date().toISOString(),
      lastLogin: null
    };
    writeJSON(USERS_FILE, [adminUser]);
    console.log('✅ Admin user seeded.');
  }

  // Seed default items
  if (!fs.existsSync(ITEMS_FILE) || readJSON(ITEMS_FILE).length === 0) {
    const defaultItems = [
      { id: uuidv4(), name: 'Matar', price: 150, unit: 'kg', image: '/images/matar.jpg', description: 'Crispy and spiced green peas, a classic Indian namkeen perfect for tea-time snacking.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Small Samosa Mathi', price: 150, unit: 'kg', image: '/images/small-samosa-mathi.jpg', description: 'Bite-sized samosa-shaped mathri with a crunchy, flaky texture and aromatic spice blend.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Bhujia', price: 40, unit: 'packet', image: '/images/bhujia.jpg', description: 'Fine, crispy besan sev with a hint of spice — the quintessential Indian snack.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Khurme', price: 150, unit: 'kg', image: '/images/khurme.jpg', description: 'Traditional sweet and crunchy wheat flour treats glazed with sugar syrup.', category: 'Sweets' },
      { id: uuidv4(), name: 'Balusahi', price: 150, unit: 'kg', image: '/images/balusahi.jpg', description: 'Soft, flaky, and melt-in-your-mouth traditional sweet soaked in sugar syrup.', category: 'Sweets' },
      { id: uuidv4(), name: 'Kaju', price: 180, unit: 'kg', image: '/images/kaju.jpg', description: 'Premium cashew namkeen — rich, crispy, and crafted from finest quality cashews.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Kachori', price: 180, unit: 'kg', image: '/images/kachori.jpg', description: 'Crispy deep-fried pastry filled with spiced moong dal or onion filling.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Big Samosa Mathi', price: 150, unit: 'kg', image: '/images/big-samosa-mathi.jpg', description: 'Large samosa-shaped mathri with extra crunch and bold spices — perfect party snack.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Small Round Mathi', price: 150, unit: 'kg', image: '/images/small-round-mathi.jpg', description: 'Petite round mathri biscuits with a satisfying crunch and subtle cumin flavor.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Big Round Mathi', price: 150, unit: 'kg', image: '/images/big-round-mathi.jpg', description: 'Generous-sized round mathri with a hearty crunch, ideal for snack platters.', category: 'Namkeen' },
      { id: uuidv4(), name: 'Papdi', price: 180, unit: 'kg', image: '/images/papdi.jpg', description: 'Traditional crispy and savory gram flour crackers spiced with carom seeds.', category: 'Namkeen' }
    ];
    writeJSON(ITEMS_FILE, defaultItems);
    console.log('✅ Default items seeded (11 items).');
  }

  // Seed empty feedback
  if (!fs.existsSync(FEEDBACK_FILE)) {
    writeJSON(FEEDBACK_FILE, []);
    console.log('✅ Feedback file initialized.');
  }
}

// --- Initialize on require ---
ensureDataDir();
seedDatabase();

// --- Database API ---

const db = {
  // ===== Users =====
  users: {
    getAll() {
      return readJSON(USERS_FILE);
    },

    getById(id) {
      const users = readJSON(USERS_FILE);
      return users.find(u => u.id === id) || null;
    },

    getByEmail(email) {
      const users = readJSON(USERS_FILE);
      return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
    },

    create({ name, phone, email, address, password }) {
      const users = readJSON(USERS_FILE);
      const newUser = {
        id: uuidv4(),
        name,
        phone: phone || '',
        email,
        address: address || '',
        password,
        isAdmin: false,
        createdAt: new Date().toISOString(),
        lastLogin: null
      };
      users.push(newUser);
      writeJSON(USERS_FILE, users);
      return newUser;
    },

    update(id, fields) {
      const users = readJSON(USERS_FILE);
      const index = users.findIndex(u => u.id === id);
      if (index === -1) return null;
      // Only update allowed fields, don't overwrite id/isAdmin/password via this method
      const allowedFields = ['name', 'phone', 'email', 'address', 'lastLogin', 'password'];
      for (const key of allowedFields) {
        if (fields[key] !== undefined) {
          users[index][key] = fields[key];
        }
      }
      writeJSON(USERS_FILE, users);
      return users[index];
    },

    delete(id) {
      const users = readJSON(USERS_FILE);
      const index = users.findIndex(u => u.id === id);
      if (index === -1) return false;
      users.splice(index, 1);
      writeJSON(USERS_FILE, users);
      return true;
    }
  },

  // ===== Items =====
  items: {
    getAll() {
      return readJSON(ITEMS_FILE);
    },

    getById(id) {
      const items = readJSON(ITEMS_FILE);
      return items.find(i => i.id === id) || null;
    },

    create({ name, price, unit, image, description, category }) {
      const items = readJSON(ITEMS_FILE);
      const newItem = {
        id: uuidv4(),
        name,
        price,
        unit: unit || 'kg',
        image: image || '',
        description: description || '',
        category: category || 'Uncategorized'
      };
      items.push(newItem);
      writeJSON(ITEMS_FILE, items);
      return newItem;
    },

    update(id, fields) {
      const items = readJSON(ITEMS_FILE);
      const index = items.findIndex(i => i.id === id);
      if (index === -1) return null;
      const allowedFields = ['name', 'price', 'unit', 'image', 'description', 'category'];
      for (const key of allowedFields) {
        if (fields[key] !== undefined) {
          items[index][key] = fields[key];
        }
      }
      writeJSON(ITEMS_FILE, items);
      return items[index];
    },

    delete(id) {
      const items = readJSON(ITEMS_FILE);
      const index = items.findIndex(i => i.id === id);
      if (index === -1) return false;
      items.splice(index, 1);
      writeJSON(ITEMS_FILE, items);
      return true;
    },

    search(query) {
      const items = readJSON(ITEMS_FILE);
      const q = query.toLowerCase();
      return items.filter(i =>
        i.name.toLowerCase().includes(q) ||
        i.description.toLowerCase().includes(q) ||
        i.category.toLowerCase().includes(q)
      );
    }
  },

  // ===== Feedback =====
  feedback: {
    getAll() {
      return readJSON(FEEDBACK_FILE);
    },

    create({ userId, userName, rating, review }) {
      const feedback = readJSON(FEEDBACK_FILE);
      const newFeedback = {
        id: uuidv4(),
        userId,
        userName,
        rating: Number(rating),
        review: review || '',
        createdAt: new Date().toISOString()
      };
      feedback.push(newFeedback);
      writeJSON(FEEDBACK_FILE, feedback);
      return newFeedback;
    },

    delete(id) {
      const feedback = readJSON(FEEDBACK_FILE);
      const index = feedback.findIndex(f => f.id === id);
      if (index === -1) return false;
      feedback.splice(index, 1);
      writeJSON(FEEDBACK_FILE, feedback);
      return true;
    }
  }
};

module.exports = db;
