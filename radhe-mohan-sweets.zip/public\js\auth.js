/* ============================================
   AUTH — Login, Register, Profile
   ============================================ */

(function() {
  // ---------- Auth Tab Switching ----------
  document.addEventListener('DOMContentLoaded', () => {
    const authTabs = document.querySelectorAll('.auth-tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const authHeading = document.getElementById('auth-heading');

    authTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        authTabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const tabName = tab.dataset.tab;
        if (tabName === 'login') {
          loginForm.style.display = 'block';
          registerForm.style.display = 'none';
          if (authHeading) authHeading.textContent = 'Welcome Back';
        } else {
          loginForm.style.display = 'none';
          registerForm.style.display = 'block';
          if (authHeading) authHeading.textContent = 'Create Account';
        }

        // Clear errors
        hideError('login-error');
        hideError('register-error');
        hideSuccess('register-success');
      });
    });

    // ---------- Login Form ----------
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideError('login-error');

        const email = document.getElementById('login-email').value.trim();
        const password = document.getElementById('login-password').value;

        if (!email || !password) {
          showError('login-error', 'Please fill in all fields');
          return;
        }

        const btn = loginForm.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Logging in...';

        try {
          const data = await api('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
          });

          authToken = data.token;
          currentUser = data.user;
          localStorage.setItem('rms_token', data.token);
          updateAuthUI();
          loginForm.reset();
          navigateTo('home');
          showToast(`Welcome back, ${currentUser.name}! 🎉`);
        } catch (err) {
          showError('login-error', err.message || 'Login failed');
        } finally {
          btn.disabled = false;
          btn.textContent = 'Login';
        }
      });
    }

    // ---------- Register Form ----------
    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideError('register-error');
        hideSuccess('register-success');

        const name = document.getElementById('reg-name').value.trim();
        const phone = document.getElementById('reg-phone').value.trim();
        const email = document.getElementById('reg-email').value.trim();
        const address = document.getElementById('reg-address').value.trim();
        const password = document.getElementById('reg-password').value;

        if (!name || !phone || !email || !password) {
          showError('register-error', 'Please fill in all required fields');
          return;
        }

        if (password.length < 6) {
          showError('register-error', 'Password must be at least 6 characters');
          return;
        }

        const btn = registerForm.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Creating account...';

        try {
          const data = await api('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify({ name, phone, email, address, password })
          });

          authToken = data.token;
          currentUser = data.user;
          localStorage.setItem('rms_token', data.token);
          updateAuthUI();
          registerForm.reset();
          navigateTo('home');
          showToast(`Welcome, ${currentUser.name}! Account created 🎉`);
        } catch (err) {
          showError('register-error', err.message || 'Registration failed');
        } finally {
          btn.disabled = false;
          btn.textContent = 'Create Account';
        }
      });
    }

    // ---------- Profile Edit ----------
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const editProfileForm = document.getElementById('edit-profile-form');
    const cancelEditBtn = document.getElementById('cancel-edit');

    if (editProfileBtn) {
      editProfileBtn.addEventListener('click', () => {
        if (!currentUser) return;
        document.getElementById('edit-name').value = currentUser.name || '';
        document.getElementById('edit-phone').value = currentUser.phone || '';
        document.getElementById('edit-address').value = currentUser.address || '';
        editProfileForm.style.display = 'block';
        editProfileBtn.style.display = 'none';
      });
    }

    if (cancelEditBtn) {
      cancelEditBtn.addEventListener('click', () => {
        editProfileForm.style.display = 'none';
        editProfileBtn.style.display = 'inline-flex';
      });
    }

    if (editProfileForm) {
      editProfileForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const name = document.getElementById('edit-name').value.trim();
        const phone = document.getElementById('edit-phone').value.trim();
        const address = document.getElementById('edit-address').value.trim();

        try {
          const data = await api('/api/auth/profile', {
            method: 'PUT',
            body: JSON.stringify({ name, phone, address })
          });

          currentUser = data.user;
          loadProfile();
          editProfileForm.style.display = 'none';
          editProfileBtn.style.display = 'inline-flex';
          showToast('Profile updated successfully ✅');
        } catch (err) {
          showToast(err.message || 'Failed to update profile', 'error');
        }
      });
    }
  });

  // ---------- Helpers ----------
  function showError(id, message) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = message;
      el.classList.add('show');
      el.style.display = 'block';
    }
  }

  function hideError(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('show');
      el.style.display = 'none';
    }
  }

  function hideSuccess(id) {
    const el = document.getElementById(id);
    if (el) {
      el.classList.remove('show');
      el.style.display = 'none';
    }
  }
})();

// ---------- Load Profile (global) ----------
function loadProfile() {
  if (!currentUser) {
    navigateTo('login');
    return;
  }

  document.getElementById('profile-name').textContent = currentUser.name || 'User';
  document.getElementById('profile-email').textContent = currentUser.email || '—';
  document.getElementById('profile-phone').textContent = currentUser.phone || '—';
  document.getElementById('profile-address').textContent = currentUser.address || '—';

  const badge = document.getElementById('profile-badge');
  if (badge) {
    badge.style.display = currentUser.isAdmin ? 'inline-block' : 'none';
  }

  // Reset edit form state
  const editForm = document.getElementById('edit-profile-form');
  const editBtn = document.getElementById('edit-profile-btn');
  if (editForm) editForm.style.display = 'none';
  if (editBtn) editBtn.style.display = 'inline-flex';
}
