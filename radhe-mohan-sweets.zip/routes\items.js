const express = require('express');
const router = express.Router();
const db = require('../database');
const { authenticate, isAdmin } = require('../middleware/auth');

/**
 * GET /api/items
 * Get all items (public).
 */
router.get('/', (req, res) => {
  try {
    const items = db.items.getAll();
    return res.json({ success: true, items });
  } catch (err) {
    console.error('Get items error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching items.' });
  }
});

/**
 * GET /api/items/search?q=query
 * Search items by name, description, or category (public).
 */
router.get('/search', (req, res) => {
  try {
    const query = req.query.q;
    if (!query) {
      return res.status(400).json({ success: false, message: 'Search query parameter "q" is required.' });
    }
    const items = db.items.search(query);
    return res.json({ success: true, items });
  } catch (err) {
    console.error('Search items error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error searching items.' });
  }
});

/**
 * GET /api/items/:id
 * Get a single item by ID (public).
 */
router.get('/:id', (req, res) => {
  try {
    const item = db.items.getById(req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Item not found.' });
    }
    return res.json({ success: true, item });
  } catch (err) {
    console.error('Get item error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching item.' });
  }
});

/**
 * POST /api/items
 * Add a new item (admin only).
 */
router.post('/', authenticate, isAdmin, (req, res) => {
  try {
    const { name, price, unit, image, description, category } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({ success: false, message: 'Name and price are required.' });
    }

    const item = db.items.create({ name, price, unit, image, description, category });
    return res.status(201).json({ success: true, item });
  } catch (err) {
    console.error('Create item error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error creating item.' });
  }
});

/**
 * PUT /api/items/:id
 * Update an existing item (admin only).
 */
router.put('/:id', authenticate, isAdmin, (req, res) => {
  try {
    const { name, price, unit, image, description, category } = req.body;

    const updates = {};
    if (name !== undefined) updates.name = name;
    if (price !== undefined) updates.price = price;
    if (unit !== undefined) updates.unit = unit;
    if (image !== undefined) updates.image = image;
    if (description !== undefined) updates.description = description;
    if (category !== undefined) updates.category = category;

    const updatedItem = db.items.update(req.params.id, updates);
    if (!updatedItem) {
      return res.status(404).json({ success: false, message: 'Item not found.' });
    }

    return res.json({ success: true, item: updatedItem });
  } catch (err) {
    console.error('Update item error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error updating item.' });
  }
});

/**
 * DELETE /api/items/:id
 * Delete an item (admin only).
 */
router.delete('/:id', authenticate, isAdmin, (req, res) => {
  try {
    const deleted = db.items.delete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Item not found.' });
    }
    return res.json({ success: true, message: 'Item deleted successfully.' });
  } catch (err) {
    console.error('Delete item error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error deleting item.' });
  }
});

module.exports = router;
