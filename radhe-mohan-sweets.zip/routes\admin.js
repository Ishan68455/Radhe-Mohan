const express = require('express');
const router = express.Router();
const db = require('../database');
const { authenticate, isAdmin } = require('../middleware/auth');

// All admin routes require authentication + admin privileges
router.use(authenticate, isAdmin);

/**
 * GET /api/admin/users
 * Get all registered users (without passwords).
 */
router.get('/users', (req, res) => {
  try {
    const users = db.users.getAll();
    // Strip passwords from all user objects
    const usersWithoutPasswords = users.map(({ password, ...user }) => user);
    return res.json({ success: true, users: usersWithoutPasswords });
  } catch (err) {
    console.error('Admin get users error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching users.' });
  }
});

/**
 * GET /api/admin/stats
 * Get dashboard statistics.
 */
router.get('/stats', (req, res) => {
  try {
    const users = db.users.getAll();
    const feedback = db.feedback.getAll();
    const items = db.items.getAll();

    const totalUsers = users.length;
    const totalFeedback = feedback.length;
    const totalItems = items.length;

    let averageRating = 0;
    if (totalFeedback > 0) {
      const sumRatings = feedback.reduce((sum, f) => sum + f.rating, 0);
      averageRating = parseFloat((sumRatings / totalFeedback).toFixed(2));
    }

    return res.json({
      success: true,
      totalUsers,
      totalFeedback,
      averageRating,
      totalItems
    });
  } catch (err) {
    console.error('Admin stats error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching stats.' });
  }
});

/**
 * DELETE /api/admin/users/:id
 * Delete a user by ID.
 */
router.delete('/users/:id', (req, res) => {
  try {
    const deleted = db.users.delete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }
    return res.json({ success: true, message: 'User deleted successfully.' });
  } catch (err) {
    console.error('Admin delete user error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error deleting user.' });
  }
});

module.exports = router;
