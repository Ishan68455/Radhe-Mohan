/* ============================================
   FEEDBACK — Star Rating, Submit, Display Reviews
   ============================================ */

let selectedRating = 0;

const ratingLabels = {
  1: 'Poor 😞',
  2: 'Fair 😐',
  3: 'Good 🙂',
  4: 'Very Good 😊',
  5: 'Excellent 🤩'
};

(function() {
  document.addEventListener('DOMContentLoaded', () => {
    initStarRating();
    initFeedbackForm();
  });

  // ---------- Star Rating Interaction ----------
  function initStarRating() {
    const starContainer = document.getElementById('star-rating');
    if (!starContainer) return;

    const stars = starContainer.querySelectorAll('.star');
    const ratingText = document.getElementById('rating-text');

    stars.forEach(star => {
      star.addEventListener('mouseenter', () => {
        const rating = parseInt(star.dataset.rating);
        highlightStars(stars, rating);
        if (ratingText) ratingText.textContent = ratingLabels[rating] || '';
      });

      star.addEventListener('mouseleave', () => {
        highlightStars(stars, selectedRating);
        if (ratingText) {
          ratingText.textContent = selectedRating
            ? ratingLabels[selectedRating]
            : 'Select your rating';
        }
      });

      star.addEventListener('click', () => {
        selectedRating = parseInt(star.dataset.rating);
        highlightStars(stars, selectedRating);
        if (ratingText) ratingText.textContent = ratingLabels[selectedRating];
      });
    });
  }

  function highlightStars(stars, rating) {
    stars.forEach(star => {
      const val = parseInt(star.dataset.rating);
      if (val <= rating) {
        star.classList.add('active');
        star.classList.remove('hovered');
      } else {
        star.classList.remove('active');
        star.classList.remove('hovered');
      }
    });
  }

  // ---------- Submit Feedback Form ----------
  function initFeedbackForm() {
    const form = document.getElementById('feedback-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const errorEl = document.getElementById('feedback-error');
      const successEl = document.getElementById('feedback-success');
      if (errorEl) { errorEl.style.display = 'none'; errorEl.classList.remove('show'); }
      if (successEl) { successEl.style.display = 'none'; successEl.classList.remove('show'); }

      if (!selectedRating) {
        if (errorEl) {
          errorEl.textContent = 'Please select a star rating';
          errorEl.style.display = 'block';
          errorEl.classList.add('show');
        }
        return;
      }

      const review = document.getElementById('review-text').value.trim();
      const btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Submitting...';

      try {
        await api('/api/feedback', {
          method: 'POST',
          body: JSON.stringify({ rating: selectedRating, review })
        });

        // Reset form
        selectedRating = 0;
        document.getElementById('review-text').value = '';
        const stars = document.querySelectorAll('#star-rating .star');
        stars.forEach(s => s.classList.remove('active'));
        const ratingText = document.getElementById('rating-text');
        if (ratingText) ratingText.textContent = 'Select your rating';

        if (successEl) {
          successEl.textContent = 'Review submitted! Thank you 🎉';
          successEl.style.display = 'block';
          successEl.classList.add('show');
          setTimeout(() => { successEl.style.display = 'none'; }, 3000);
        }

        showToast('Review submitted! Thank you ⭐');
        loadFeedback();
      } catch (err) {
        if (errorEl) {
          errorEl.textContent = err.message || 'Failed to submit review';
          errorEl.style.display = 'block';
          errorEl.classList.add('show');
        }
      } finally {
        btn.disabled = false;
        btn.textContent = 'Submit Review';
      }
    });
  }
})();

// ---------- Update Feedback UI Based on Auth ----------
function updateFeedbackUI() {
  const formContainer = document.getElementById('feedback-form-container');
  const loginPrompt = document.getElementById('login-to-review');

  if (currentUser) {
    if (formContainer) formContainer.style.display = 'block';
    if (loginPrompt) loginPrompt.style.display = 'none';
  } else {
    if (formContainer) formContainer.style.display = 'none';
    if (loginPrompt) loginPrompt.style.display = 'block';
  }
}

// ---------- Load All Reviews ----------
async function loadFeedback() {
  const list = document.getElementById('reviews-list');
  const noReviews = document.getElementById('no-reviews');
  if (!list) return;

  list.innerHTML = '<div class="loading-spinner"></div>';

  try {
    const data = await api('/api/feedback');
    const reviews = data.feedback || [];

    // Sort newest first
    reviews.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (reviews.length === 0) {
      list.innerHTML = '';
      if (noReviews) noReviews.style.display = 'block';
      return;
    }

    if (noReviews) noReviews.style.display = 'none';

    list.innerHTML = reviews.map(review => {
      const initial = (review.userName || 'U').charAt(0).toUpperCase();
      const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
      const date = new Date(review.createdAt).toLocaleDateString('en-IN', {
        day: 'numeric', month: 'short', year: 'numeric'
      });

      return `
        <div class="review-card">
          <div class="review-header">
            <div class="review-avatar">${initial}</div>
            <div>
              <h4>${review.userName || 'Anonymous'}</h4>
              <div class="review-stars">${stars}</div>
            </div>
            <span class="review-date">${date}</span>
          </div>
          ${review.review ? `<p class="review-text">${escapeHtml(review.review)}</p>` : ''}
        </div>
      `;
    }).join('');
  } catch (err) {
    list.innerHTML = '<p class="text-center" style="padding:40px; color:var(--text-muted);">Failed to load reviews.</p>';
  }
}

// ---------- HTML Escape Helper ----------
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
