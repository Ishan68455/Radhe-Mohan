const express = require('express');
const router = express.Router();
const db = require('../database');
const { authenticate, isAdmin } = require('../middleware/auth');

/**
 * GET /api/feedback
 * Get all feedback, sorted by createdAt descending (public).
 */
router.get('/', (req, res) => {
  try {
    const feedback = db.feedback.getAll();
    // Sort by createdAt descending (newest first)
    feedback.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return res.json({ success: true, feedback });
  } catch (err) {
    console.error('Get feedback error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching feedback.' });
  }
});

/**
 * POST /api/feedback
 * Submit feedback (authenticated users only).
 */
router.post('/', authenticate, (req, res) => {
  try {
    const { rating, review } = req.body;

    // Validate rating
    if (rating === undefined || rating === null) {
      return res.status(400).json({ success: false, message: 'Rating is required.' });
    }

    const ratingNum = Number(rating);
    if (isNaN(ratingNum) || ratingNum < 1 || ratingNum > 5) {
      return res.status(400).json({ success: false, message: 'Rating must be a number between 1 and 5.' });
    }

    const newFeedback = db.feedback.create({
      userId: req.user.id,
      userName: req.user.name,
      rating: ratingNum,
      review: review || ''
    });

    return res.status(201).json({ success: true, feedback: newFeedback });
  } catch (err) {
    console.error('Create feedback error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error submitting feedback.' });
  }
});

/**
 * DELETE /api/feedback/:id
 * Delete feedback (admin only).
 */
router.delete('/:id', authenticate, isAdmin, (req, res) => {
  try {
    const deleted = db.feedback.delete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Feedback not found.' });
    }
    return res.json({ success: true, message: 'Feedback deleted successfully.' });
  } catch (err) {
    console.error('Delete feedback error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error deleting feedback.' });
  }
});

module.exports = router;
