/* ============================================
   ITEMS — Display, Filter, Search, Detail Modal
   ============================================ */

let allItems = [];
let currentFilter = 'all';

// Food emojis for fallback images
const foodEmojis = {
  'Sweets': ['🍯', '🧁', '🍬', '🍪', '🍩'],
  'Namkeen': ['🥜', '🌶️', '🫓', '🥠', '🍘']
};

function getItemEmoji(item, index) {
  const emojis = foodEmojis[item.category] || foodEmojis['Namkeen'];
  return emojis[index % emojis.length];
}

function getBgClass(category) {
  return category === 'Sweets' ? 'sweets-bg' : 'namkeen-bg';
}

// ---------- Create Item Card HTML ----------
function createItemCard(item, index) {
  const emoji = getItemEmoji(item, index);
  const bgClass = getBgClass(item.category);

  return `
    <div class="item-card" onclick="showItemDetail('${item.id}')" data-category="${item.category}">
      <div class="item-image">
        <img 
          src="${item.image}" 
          alt="${item.name}" 
          loading="lazy"
          onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
        >
        <div class="item-image-fallback ${bgClass}" style="display:none">${emoji}</div>
        <div class="item-image-overlay"></div>
        <span class="item-category-badge">${item.category}</span>
      </div>
      <div class="item-info">
        <h3 class="item-name">${item.name}</h3>
        <span class="item-price">₹${item.price}/${item.unit}</span>
      </div>
    </div>
  `;
}

// ---------- Load All Items ----------
async function loadItems() {
  const grid = document.getElementById('items-grid');
  if (!grid) return;

  grid.innerHTML = '<div class="loading-spinner"></div>';

  try {
    const data = await api('/api/items');
    allItems = data.items || [];
    renderItems(grid, allItems);
    initFilterTabs();
  } catch (err) {
    grid.innerHTML = '<p class="text-center" style="padding:40px; color:var(--text-muted);">Failed to load items. Please try again.</p>';
  }
}

// ---------- Load Featured Items (Home Page) ----------
async function loadFeaturedItems() {
  const grid = document.getElementById('featured-items');
  if (!grid) return;

  try {
    const data = await api('/api/items');
    const items = (data.items || []).slice(0, 4);
    grid.innerHTML = items.map((item, i) => createItemCard(item, i)).join('');
  } catch (err) {
    grid.innerHTML = '<p class="text-center" style="color:var(--text-muted);">Loading items...</p>';
  }
}

// ---------- Render Items with Filter ----------
function renderItems(grid, items) {
  const filtered = currentFilter === 'all'
    ? items
    : items.filter(item => item.category === currentFilter);

  if (filtered.length === 0) {
    grid.innerHTML = '<p class="text-center" style="padding:40px; color:var(--text-muted);">No items found in this category.</p>';
    return;
  }

  grid.innerHTML = filtered.map((item, i) => createItemCard(item, i)).join('');
}

// ---------- Filter Tabs ----------
function initFilterTabs() {
  const tabs = document.querySelectorAll('.filter-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentFilter = tab.dataset.filter;

      const grid = document.getElementById('items-grid');
      renderItems(grid, allItems);
    });
  });
}

// ---------- Show Item Detail Modal ----------
async function showItemDetail(itemId) {
  const modal = document.getElementById('item-modal');
  if (!modal) return;

  // Close search results
  const sr = document.getElementById('search-results');
  if (sr) sr.style.display = 'none';

  try {
    const data = await api(`/api/items/${itemId}`);
    const item = data.item;
    if (!item) throw new Error('Item not found');

    const emoji = getItemEmoji(item, 0);
    const bgClass = getBgClass(item.category);

    document.getElementById('modal-item-name').textContent = item.name;
    document.getElementById('modal-item-category').textContent = item.category;
    document.getElementById('modal-item-description').textContent = item.description || 'Delicious traditional item from Radhe Mohan Sweets.';
    document.getElementById('modal-item-price').textContent = `₹${item.price} / ${item.unit}`;

    const imageContainer = document.getElementById('modal-item-image');
    imageContainer.innerHTML = `
      <img 
        src="${item.image}" 
        alt="${item.name}"
        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
      >
      <div class="item-image-fallback ${bgClass}" style="display:none">${emoji}</div>
    `;

    modal.style.display = 'flex';
  } catch (err) {
    showToast('Could not load item details', 'error');
  }
}
