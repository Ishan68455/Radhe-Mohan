/* ============================================
   ADMIN — Dashboard, Users, Items CRUD, Reviews
   ============================================ */

(function() {
  document.addEventListener('DOMContentLoaded', () => {
    initAdminTabs();
    initAddItemBtn();
    initItemForm();
  });

  // ---------- Admin Tab Switching ----------
  function initAdminTabs() {
    const tabs = document.querySelectorAll('.admin-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const tabName = tab.dataset.adminTab;
        document.querySelectorAll('.admin-section').forEach(section => {
          section.style.display = 'none';
          section.classList.remove('active');
        });

        const target = document.getElementById(`admin-${tabName}`);
        if (target) {
          target.style.display = 'block';
          target.classList.add('active');
        }
      });
    });
  }

  // ---------- Add Item Button ----------
  function initAddItemBtn() {
    const btn = document.getElementById('add-item-btn');
    if (btn) {
      btn.addEventListener('click', () => openItemFormModal());
    }
  }

  // ---------- Item Form ----------
  function initItemForm() {
    const form = document.getElementById('item-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const id = document.getElementById('item-form-id').value;
      const name = document.getElementById('item-form-name').value.trim();
      const price = parseFloat(document.getElementById('item-form-price').value);
      const unit = document.getElementById('item-form-unit').value;
      const category = document.getElementById('item-form-category').value;
      const description = document.getElementById('item-form-desc').value.trim();
      const image = document.getElementById('item-form-image').value.trim();

      if (!name || isNaN(price)) {
        showToast('Please fill name and price', 'error');
        return;
      }

      try {
        if (id) {
          // Update
          await api(`/api/items/${id}`, {
            method: 'PUT',
            body: JSON.stringify({ name, price, unit, category, description, image })
          });
          showToast('Item updated successfully ✅');
        } else {
          // Create
          await api('/api/items', {
            method: 'POST',
            body: JSON.stringify({ name, price, unit, category, description, image })
          });
          showToast('Item added successfully ✅');
        }

        closeItemFormModal();
        loadAdminItems();
      } catch (err) {
        showToast(err.message || 'Failed to save item', 'error');
      }
    });
  }
})();

// ---------- Open/Close Item Form Modal ----------
function openItemFormModal(item = null) {
  const modal = document.getElementById('item-form-modal');
  const title = document.getElementById('item-form-title');
  const form = document.getElementById('item-form');

  if (item) {
    title.textContent = 'Edit Item';
    document.getElementById('item-form-id').value = item.id;
    document.getElementById('item-form-name').value = item.name || '';
    document.getElementById('item-form-price').value = item.price || '';
    document.getElementById('item-form-unit').value = item.unit || 'kg';
    document.getElementById('item-form-category').value = item.category || 'Namkeen';
    document.getElementById('item-form-desc').value = item.description || '';
    document.getElementById('item-form-image').value = item.image || '';
  } else {
    title.textContent = 'Add New Item';
    form.reset();
    document.getElementById('item-form-id').value = '';
  }

  modal.style.display = 'flex';
}

function closeItemFormModal() {
  const modal = document.getElementById('item-form-modal');
  if (modal) modal.style.display = 'none';
}

// ---------- Load All Admin Data ----------
async function loadAdminData() {
  await Promise.all([
    loadAdminStats(),
    loadAdminUsers(),
    loadAdminItems(),
    loadAdminReviews()
  ]);
}

// ---------- Admin Stats ----------
async function loadAdminStats() {
  const container = document.getElementById('admin-stats');
  if (!container) return;

  try {
    const data = await api('/api/admin/stats');
    const stats = data.stats;

    container.innerHTML = `
      <div class="stat-card">
        <div class="stat-value">${stats.totalUsers}</div>
        <div class="stat-title">👥 Total Users</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${stats.totalItems}</div>
        <div class="stat-title">🛍️ Total Items</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${stats.totalFeedback}</div>
        <div class="stat-title">⭐ Total Reviews</div>
      </div>
      <div class="stat-card">
        <div class="stat-value">${stats.averageRating ? stats.averageRating.toFixed(1) : '—'}</div>
        <div class="stat-title">📊 Avg Rating</div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = '<p style="color:var(--text-muted);">Failed to load stats</p>';
  }
}

// ---------- Admin Users Table ----------
async function loadAdminUsers() {
  const tbody = document.getElementById('admin-users-tbody');
  if (!tbody) return;

  try {
    const data = await api('/api/admin/users');
    const users = data.users || [];

    if (users.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px;">No users found</td></tr>';
      return;
    }

    tbody.innerHTML = users.map(user => {
      const date = new Date(user.createdAt).toLocaleDateString('en-IN', {
        day: 'numeric', month: 'short', year: 'numeric'
      });

      return `
        <tr>
          <td><strong>${escapeHtml(user.name)}</strong>${user.isAdmin ? ' <span class="profile-badge" style="font-size:0.6rem;padding:2px 6px;">Admin</span>' : ''}</td>
          <td>${escapeHtml(user.phone || '—')}</td>
          <td>${escapeHtml(user.email)}</td>
          <td>${escapeHtml(user.address || '—')}</td>
          <td>${date}</td>
          <td>
            ${!user.isAdmin ? `<button class="btn btn-danger btn-sm" onclick="deleteUser('${user.id}')">Delete</button>` : '—'}
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px;">Failed to load users</td></tr>';
  }
}

// ---------- Admin Items List ----------
async function loadAdminItems() {
  const container = document.getElementById('admin-items-list');
  if (!container) return;

  try {
    const data = await api('/api/items');
    const items = data.items || [];

    if (items.length === 0) {
      container.innerHTML = '<p style="text-align:center; padding:20px; color:var(--text-muted);">No items. Add one above!</p>';
      return;
    }

    const emojis = { 'Sweets': '🍯', 'Namkeen': '🥜' };

    container.innerHTML = items.map(item => `
      <div class="admin-item-card">
        <div class="admin-item-img">
          ${item.image
            ? `<img src="${item.image}" alt="${item.name}" onerror="this.style.display='none'; this.parentElement.innerHTML='${emojis[item.category] || '🍽️'}';">`
            : (emojis[item.category] || '🍽️')
          }
        </div>
        <div class="admin-item-info">
          <h4>${escapeHtml(item.name)}</h4>
          <p>₹${item.price}/${item.unit} · ${item.category}</p>
        </div>
        <div class="admin-item-actions">
          <button class="btn btn-outline btn-sm" onclick='editItem(${JSON.stringify(item).replace(/'/g, "\\'")})'>Edit</button>
          <button class="btn btn-danger btn-sm" onclick="deleteItem('${item.id}')">Delete</button>
        </div>
      </div>
    `).join('');
  } catch (err) {
    container.innerHTML = '<p style="text-align:center; padding:20px; color:var(--text-muted);">Failed to load items</p>';
  }
}

// ---------- Admin Reviews ----------
async function loadAdminReviews() {
  const container = document.getElementById('admin-reviews-list');
  if (!container) return;

  try {
    const data = await api('/api/feedback');
    const reviews = (data.feedback || []).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (reviews.length === 0) {
      container.innerHTML = '<p style="text-align:center; padding:20px; color:var(--text-muted);">No reviews yet</p>';
      return;
    }

    container.innerHTML = reviews.map(review => {
      const stars = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
      const date = new Date(review.createdAt).toLocaleDateString('en-IN', {
        day: 'numeric', month: 'short', year: 'numeric'
      });
      const initial = (review.userName || 'U').charAt(0).toUpperCase();

      return `
        <div class="review-card" style="display:flex; justify-content:space-between; align-items:flex-start;">
          <div style="flex:1">
            <div class="review-header">
              <div class="review-avatar">${initial}</div>
              <div>
                <h4>${escapeHtml(review.userName || 'Anonymous')}</h4>
                <div class="review-stars">${stars}</div>
              </div>
              <span class="review-date">${date}</span>
            </div>
            ${review.review ? `<p class="review-text">${escapeHtml(review.review)}</p>` : ''}
          </div>
          <button class="btn btn-danger btn-sm" onclick="deleteReview('${review.id}')" style="margin-left:12px; flex-shrink:0;">Delete</button>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = '<p style="text-align:center; padding:20px; color:var(--text-muted);">Failed to load reviews</p>';
  }
}

// ---------- Action Functions ----------
async function deleteUser(userId) {
  if (!confirm('Are you sure you want to delete this user?')) return;

  try {
    await api(`/api/admin/users/${userId}`, { method: 'DELETE' });
    showToast('User deleted ✅');
    loadAdminUsers();
    loadAdminStats();
  } catch (err) {
    showToast(err.message || 'Failed to delete user', 'error');
  }
}

function editItem(item) {
  openItemFormModal(item);
}

async function deleteItem(itemId) {
  if (!confirm('Are you sure you want to delete this item?')) return;

  try {
    await api(`/api/items/${itemId}`, { method: 'DELETE' });
    showToast('Item deleted ✅');
    loadAdminItems();
    loadAdminStats();
  } catch (err) {
    showToast(err.message || 'Failed to delete item', 'error');
  }
}

async function deleteReview(reviewId) {
  if (!confirm('Are you sure you want to delete this review?')) return;

  try {
    await api(`/api/feedback/${reviewId}`, { method: 'DELETE' });
    showToast('Review deleted ✅');
    loadAdminReviews();
    loadAdminStats();
  } catch (err) {
    showToast(err.message || 'Failed to delete review', 'error');
  }
}

// ---------- HTML Escape (if not already defined) ----------
if (typeof escapeHtml === 'undefined') {
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}
