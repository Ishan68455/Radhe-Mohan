const jwt = require('jsonwebtoken');
const db = require('../database');

const JWT_SECRET = 'radhe_mohan_sweets_secret_key_2024';

/**
 * Authenticate middleware - extracts and verifies JWT from Authorization header.
 * On success, attaches the full user object (from DB) to req.user.
 */
function authenticate(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Access denied. No token provided.' });
    }

    const token = authHeader.split(' ')[1];

    const decoded = jwt.verify(token, JWT_SECRET);

    // Fetch fresh user data from the database
    const user = db.users.getById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid token. User not found.' });
    }

    // Attach user to request (without password)
    const { password, ...userWithoutPassword } = user;
    req.user = userWithoutPassword;

    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, message: 'Token has expired. Please login again.' });
    }
    return res.status(401).json({ success: false, message: 'Invalid token.' });
  }
}

/**
 * isAdmin middleware - must be used AFTER authenticate.
 * Checks if the authenticated user has admin privileges.
 */
function isAdmin(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ success: false, message: 'Access denied. Admin privileges required.' });
  }
  next();
}

module.exports = { authenticate, isAdmin, JWT_SECRET };
