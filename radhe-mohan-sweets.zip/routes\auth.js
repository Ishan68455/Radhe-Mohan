const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authenticate, JWT_SECRET } = require('../middleware/auth');

/**
 * POST /api/auth/register
 * Register a new user account.
 */
router.post('/register', async (req, res) => {
  try {
    const { name, phone, email, address, password } = req.body;

    // Validate required fields
    if (!name || !email || !password || !phone) {
      return res.status(400).json({
        success: false,
        message: 'Name, phone, email, and password are required.'
      });
    }

    // Check if email already registered
    const existingUser = db.users.getByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email already exists.'
      });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = db.users.create({
      name,
      phone,
      email,
      address: address || '',
      password: hashedPassword
    });

    // Generate JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, isAdmin: user.isAdmin },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        address: user.address,
        isAdmin: user.isAdmin
      }
    });
  } catch (err) {
    console.error('Register error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error during registration.' });
  }
});

/**
 * POST /api/auth/login
 * Authenticate user and return JWT.
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    // Find user by email
    const user = db.users.getByEmail(email);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    // Update lastLogin
    db.users.update(user.id, { lastLogin: new Date().toISOString() });

    // Generate JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, isAdmin: user.isAdmin },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        address: user.address,
        isAdmin: user.isAdmin
      }
    });
  } catch (err) {
    console.error('Login error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error during login.' });
  }
});

/**
 * GET /api/auth/profile
 * Get current user's profile. Requires authentication.
 */
router.get('/profile', authenticate, (req, res) => {
  try {
    return res.json({
      success: true,
      user: req.user // password already stripped by authenticate middleware
    });
  } catch (err) {
    console.error('Profile fetch error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error fetching profile.' });
  }
});

/**
 * PUT /api/auth/profile
 * Update current user's profile. Requires authentication.
 */
router.put('/profile', authenticate, (req, res) => {
  try {
    const { name, phone, address } = req.body;

    const updates = {};
    if (name !== undefined) updates.name = name;
    if (phone !== undefined) updates.phone = phone;
    if (address !== undefined) updates.address = address;

    const updatedUser = db.users.update(req.user.id, updates);
    if (!updatedUser) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Return without password
    const { password, ...userWithoutPassword } = updatedUser;

    return res.json({
      success: true,
      user: userWithoutPassword
    });
  } catch (err) {
    console.error('Profile update error:', err.message);
    return res.status(500).json({ success: false, message: 'Server error updating profile.' });
  }
});

module.exports = router;
