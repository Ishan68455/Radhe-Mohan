/* ============================================
   RADHE MOHAN SWEETS — Main App Controller
   Handles: splash, navigation, sidebar, search, toast, auth state
   ============================================ */

// ---------- Global State ----------
let currentUser = null;
let authToken = localStorage.getItem('rms_token');

// ---------- API Helper ----------
async function api(url, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
  
  const response = await fetch(url, {
    ...options,
    headers: { ...headers, ...options.headers }
  });
  
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

// ---------- Splash Screen ----------
function initSplash() {
  const splash = document.getElementById('splash-screen');
  if (!splash) return;
  
  // Click to skip
  splash.addEventListener('click', () => dismissSplash(splash));
  
  // Auto dismiss after 2.8s
  setTimeout(() => dismissSplash(splash), 2800);
}

function dismissSplash(splash) {
  if (splash.classList.contains('fade-out')) return;
  splash.classList.add('fade-out');
  setTimeout(() => {
    splash.style.display = 'none';
  }, 600);
}

// ---------- Navigation ----------
function navigateTo(pageName) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
  });
  
  // Show target page
  const target = document.getElementById(`page-${pageName}`);
  if (target) {
    // Force re-trigger animation
    target.style.animation = 'none';
    void target.offsetWidth;
    target.style.animation = '';
    target.classList.add('active');
  }
  
  // Close sidebar
  closeSidebar();
  
  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
  
  // Update sidebar active state
  document.querySelectorAll('.sidebar-menu li').forEach(li => {
    li.classList.toggle('active', li.dataset.page === pageName);
  });
  
  // Close search results
  const sr = document.getElementById('search-results');
  if (sr) sr.style.display = 'none';
  
  // Page-specific initializations
  switch (pageName) {
    case 'home':
      loadFeaturedItems();
      break;
    case 'items':
      loadItems();
      break;
    case 'feedback':
      loadFeedback();
      updateFeedbackUI();
      break;
    case 'profile':
      loadProfile();
      break;
    case 'admin':
      if (currentUser && currentUser.isAdmin) {
        loadAdminData();
      } else {
        navigateTo('home');
        showToast('Access denied — admin only', 'error');
      }
      break;
    case 'login':
      if (currentUser) {
        navigateTo('profile');
      }
      break;
  }
}

// ---------- Sidebar ----------
function openSidebar() {
  document.getElementById('sidebar').classList.add('active');
  document.getElementById('sidebar-overlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('active');
  document.getElementById('sidebar-overlay').classList.remove('active');
  document.body.style.overflow = '';
}

// ---------- Search ----------
function initSearch() {
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');
  if (!input || !results) return;
  
  let debounceTimer;
  
  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const query = input.value.trim();
    
    if (query.length < 2) {
      results.style.display = 'none';
      return;
    }
    
    debounceTimer = setTimeout(async () => {
      try {
        const data = await api(`/api/items/search?q=${encodeURIComponent(query)}`);
        if (data.items && data.items.length > 0) {
          results.innerHTML = data.items.map(item =>
            `<div class="search-result-item" onclick="showItemDetail('${item.id}')">
              <span>${item.name}</span>
              <span>₹${item.price}/${item.unit}</span>
            </div>`
          ).join('');
          results.style.display = 'block';
        } else {
          results.innerHTML = '<div class="search-result-item"><span>No items found</span></div>';
          results.style.display = 'block';
        }
      } catch (e) {
        results.style.display = 'none';
      }
    }, 300);
  });
  
  // Close on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-container')) {
      results.style.display = 'none';
    }
  });
  
  // Enter key navigates to items page
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      navigateTo('items');
      results.style.display = 'none';
    }
  });
}

// ---------- Toast Notification ----------
function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  setTimeout(() => toast.classList.remove('show'), 3500);
}

// ---------- Auth State UI ----------
function updateAuthUI() {
  const loginBtn = document.getElementById('sidebar-login-btn');
  const logoutBtn = document.getElementById('sidebar-logout-btn');
  const adminNav = document.getElementById('admin-nav-item');
  const profileBtn = document.getElementById('profile-btn');
  
  if (currentUser) {
    if (loginBtn) loginBtn.style.display = 'none';
    if (logoutBtn) logoutBtn.style.display = 'flex';
    if (adminNav) adminNav.style.display = currentUser.isAdmin ? 'flex' : 'none';
    if (profileBtn) profileBtn.onclick = () => navigateTo('profile');
  } else {
    if (loginBtn) loginBtn.style.display = 'flex';
    if (logoutBtn) logoutBtn.style.display = 'none';
    if (adminNav) adminNav.style.display = 'none';
    if (profileBtn) profileBtn.onclick = () => navigateTo('login');
  }
}

function logout() {
  authToken = null;
  currentUser = null;
  localStorage.removeItem('rms_token');
  updateAuthUI();
  navigateTo('home');
  showToast('Logged out successfully');
}

// ---------- Navbar Scroll Effect ----------
function initNavbarScroll() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });
}

// ---------- Initialize ----------
document.addEventListener('DOMContentLoaded', () => {
  // Splash
  initSplash();
  
  // Search
  initSearch();
  
  // Navbar scroll
  initNavbarScroll();
  
  // Sidebar events
  document.getElementById('hamburger-btn').addEventListener('click', openSidebar);
  document.getElementById('close-sidebar').addEventListener('click', closeSidebar);
  document.getElementById('sidebar-overlay').addEventListener('click', closeSidebar);
  
  // Sidebar menu items
  document.querySelectorAll('.sidebar-menu li').forEach(li => {
    li.addEventListener('click', () => {
      const page = li.dataset.page;
      if (page) navigateTo(page);
    });
  });
  
  // Sidebar auth buttons
  document.getElementById('sidebar-login-btn').addEventListener('click', () => navigateTo('login'));
  document.getElementById('sidebar-logout-btn').addEventListener('click', logout);
  
  // Profile button
  document.getElementById('profile-btn').addEventListener('click', () => {
    navigateTo(currentUser ? 'profile' : 'login');
  });
  
  // Item detail modal close
  document.getElementById('close-item-modal').addEventListener('click', () => {
    document.getElementById('item-modal').style.display = 'none';
  });
  
  // Close modals on overlay click
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });
  });
  
  // Keyboard escape closes modals & sidebar
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSidebar();
      document.querySelectorAll('.modal').forEach(m => m.style.display = 'none');
    }
  });
  
  // Check if user is logged in (restore session)
  if (authToken) {
    api('/api/auth/profile')
      .then(data => {
        currentUser = data.user;
        updateAuthUI();
      })
      .catch(() => {
        authToken = null;
        localStorage.removeItem('rms_token');
        updateAuthUI();
      });
  } else {
    updateAuthUI();
  }
  
  // Load home page data
  loadFeaturedItems();
});
